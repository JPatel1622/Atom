﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atom.Domain.Enum
{
    public enum CSSVariableEnum
    {
        BackgroundColor = 1,
        FooterColor = 2,
        TextColor = 3,
        ButtonColor = 4,

    }
}
