﻿namespace Atom.Domain.Enum
{
    public enum EventType
    {
        EventBrite = 1,
        TicketMaster = 2,
    }
}
