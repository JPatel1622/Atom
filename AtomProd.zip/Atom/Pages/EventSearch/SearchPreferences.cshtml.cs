using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Atom.Pages.EventSearch
{
    public class SearchPreferencesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
