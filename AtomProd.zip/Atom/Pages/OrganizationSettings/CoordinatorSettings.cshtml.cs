using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Atom.Pages.OrganizationSettings
{
    public class CoordinatorSettingsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
