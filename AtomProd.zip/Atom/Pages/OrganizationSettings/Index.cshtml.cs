﻿using Atom.Base;
using System;

namespace Atom.Pages.OrganizationSettings
{
    public class IndexModel : PageModelBase
    {
        public IndexModel(IServiceProvider provider) : base(provider) { }

        public void OnGet()
        {

        }
    }
}
