﻿using Atom.Base;
using System;

namespace Atom.Pages.UserSettings
{
    public class IndexModel : PageModelBase
    {
        public IndexModel(IServiceProvider provider) : base(provider)
        {
        }

        public void OnGet()
        {

        }


    }
}
