﻿using Atom.Domain.Attribute;
using Atom.Domain.Enum;
using Dapper.Contrib.Extensions;
using System;

namespace Atom.Data.BaseClass
{
    public class EntityBase
    {
    }
}
