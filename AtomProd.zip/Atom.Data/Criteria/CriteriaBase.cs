﻿using Atom.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atom.Data.Criteria
{
    public class CriteriaBase
    {
    }
}
